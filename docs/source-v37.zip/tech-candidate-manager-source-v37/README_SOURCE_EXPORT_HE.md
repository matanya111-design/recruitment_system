# חבילת קוד המקור - tech-candidate-manager

חבילה זו היא צילום של קוד המקור של גרסה 37 באתר `tech-candidate-manager`, לפי Commit:

`e6724c28fba5513a8a410d3f545166329431e72e`

## מה כלול

- ממשק המשתמש המלא ב-`app/page.tsx` וב-`app/globals.css`.
- כל נתיבי ה-API תחת `app/api/`.
- שכבת החיבור לבסיס הנתונים ב-`db/`.
- סכמת הנתונים ו-Drizzle Migrations תחת `drizzle/`.
- מנגנון Authentication ו-Authorization.
- העלאה, שמירה וחילוץ של קובצי PDF.
- חיבור ל-OpenAI Responses API.
- הנחיות ה-AI וסכמות Structured Output.
- Worker, הגדרות Build, Vite, Vinext ו-TypeScript.
- Tests וסקריפטים של התקנה, Build ואימות.
- `FILE_MANIFEST.sha256` לבדיקת שלמות הקבצים.
- מפרט ההסבה למערכת מקומית בבעלות המשתמש.

## מה לא כלול

- נתוני Production מבסיס הנתונים.
- קורות חיים או קבצים שהעלו משתמשים.
- מפתחות API, Tokens, Credentials או ערכי Environment סודיים.
- תיקיית `.git`, תיקיות Dependencies או תוצרי Build.

## נקודה חשובה

זהו קוד המקור המדויק של האתר, אבל סביבת הריצה הנוכחית משתמשת בשירותי ChatGPT Sites וב-Cloudflare:

- בסיס הנתונים הוא Cloudflare D1 דרך Binding בשם `DB`.
- הקבצים נשמרים ב-Cloudflare R2 דרך Binding בשם `BUCKET`.
- זהות המשתמש מגיעה מכותרות Authentication שמוזרקות על ידי סביבת Sites.
- מפתח OpenAI מגיע ממשתנה הסביבה `OPENAI_API_KEY`.

לכן אין לצפות שהעתקת התיקייה והרצת `npm run dev` תיצור מיד מערכת מקומית עצמאית עם כל השירותים. לצורך כך יש לפעול לפי:

`docs/tech-candidate-manager-local-rebuild-spec-he.md`

המסמך מסביר כיצד להחליף את D1 ב-PostgreSQL, את R2 ב-MinIO/S3 ואת מנגנון הזיהוי ב-Auth.js או OIDC, בלי לאבד יכולות.

## קבצי מפתח

| קובץ | תפקיד |
|---|---|
| `app/page.tsx` | כל המסכים, הטפסים וזרימות המשתמש |
| `app/globals.css` | העיצוב המלא וה-Responsive UI |
| `app/api/recruiting/route.ts` | CRUD, שאילתות, ארכיון, משתמשים והוראות AI |
| `app/api/evaluate/route.ts` | הערכת התאמה באמצעות AI |
| `app/api/cv/route.ts` | העלאה, הורדה וחילוץ PDF |
| `app/api/cv/ai/route.ts` | חילוץ פרטי מועמד באמצעות AI |
| `app/api/jobs/parse/route.ts` | יצירת טיוטת משרה מטקסט |
| `app/api/jobs/refine/route.ts` | עדכון משרה לפי מידע חדש |
| `app/api/interview/summarize/route.ts` | יצירת טיוטת סיכום ראיון |
| `app/api/session/route.ts` | פרטי המשתמש וההרשאות |
| `lib/ai-instructions.ts` | הנחיות ברירת המחדל לכל פעולות ה-AI |
| `lib/evaluation-prompt.ts` | Prompt וסכמת JSON של ההערכה |
| `lib/app-auth.ts` | Allowlist ו-Roles |
| `db/schema.ts` | מודל הנתונים ב-Drizzle |
| `drizzle/` | Migrations והיסטוריית Schema |
| `.openai/hosting.json` | הגדרת Bindings של סביבת Sites |
| `worker/index.ts` | נקודת הכניסה של Cloudflare Worker |

## בדיקת שלמות

ב-Linux או WSL, מתוך שורש החבילה:

```bash
sha256sum -c FILE_MANIFEST.sha256
```

ב-PowerShell ניתן לחשב Hash לקובץ בודד:

```powershell
Get-FileHash -Algorithm SHA256 .\app\page.tsx
```

## התחלת עבודה מומלצת ב-VS Code

1. חלץ את קובץ ה-ZIP לתיקייה חדשה.
2. פתח את התיקייה ב-VS Code.
3. קרא את הקובץ הזה ואת המפרט תחת `docs/`.
4. תן ל-Agent המקומי את ה-Prompt שבסוף המפרט.
5. בקש ממנו קודם למפות את התלויות ב-Sites ורק לאחר מכן לבצע החלפה הדרגתית באמצעות Adapters.

אין למחוק את הקוד הקיים ולהתחיל מאפס. הוא המקור המדויק ביותר למסכים, ללוגיקה העסקית, ל-Prompts ולחוזי ה-API.
