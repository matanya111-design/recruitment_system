const OWNER_EMAIL = "matanya111@googlemail.com";

export type AppIdentity = { email: string; role: "admin" | "user" };

export async function getAppIdentity(request: Request): Promise<AppIdentity | null> {
  const email = (request.headers.get("oai-authenticated-user-email") || "").trim().toLowerCase();
  if (!email) return null;
  const { env } = await import("cloudflare:workers");
  if (!env.DB) return null;
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS app_users (email TEXT PRIMARY KEY,role TEXT NOT NULL DEFAULT 'user',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare("INSERT OR IGNORE INTO app_users (email,role) VALUES (?,'admin')").bind(OWNER_EMAIL).run();
  const row = await env.DB.prepare("SELECT role FROM app_users WHERE email=?").bind(email).first<{ role: string }>();
  if (!row || !["admin", "user"].includes(row.role)) return null;
  return { email, role: row.role as "admin" | "user" };
}

export async function requireAppIdentity(request: Request) {
  const identity = await getAppIdentity(request);
  return identity || Response.json({ error: "אין הרשאה למערכת" }, { status: 403 });
}
