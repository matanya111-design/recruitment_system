import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "מערכת לניהול והערכת מועמדים",
  description: "מערכת פנימית לניהול תהליכי גיוס טכנולוגיים",
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="he" dir="rtl"><body>{children}</body></html>;
}
