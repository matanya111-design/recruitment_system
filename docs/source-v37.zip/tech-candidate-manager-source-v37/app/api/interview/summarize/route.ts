import { INTERVIEW_SUMMARY_INSTRUCTIONS } from "../../../../lib/ai-instructions";

async function getEnv() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("Database binding is unavailable");
  return env;
}

function usageAndCost(raw: Record<string, unknown>, model: string) {
  const usage = (raw.usage || {}) as Record<string, unknown>;
  const input = Number(usage.input_tokens || 0);
  const output = Number(usage.output_tokens || 0);
  const details = (usage.input_tokens_details || {}) as Record<string, unknown>;
  const cached = Number(details.cached_tokens || 0);
  const rates = model.includes("sol") ? [5, 0.5, 30] : model.includes("luna") ? [0.2, 0.02, 1.2] : [2, 0.2, 12];
  return { input, output, cached, cost: ((input - cached) * rates[0] + cached * rates[1] + output * rates[2]) / 1_000_000 };
}

const summarySchema = {
  type: "object",
  additionalProperties: false,
  required: ["summary", "uncertainties"],
  properties: {
    summary: { type: "string" },
    uncertainties: { type: "array", items: { type: "string" } },
  },
} as const;

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const body = (await request.json()) as { applicationId?: number; rawText?: string };
    const rawText = String(body.rawText || "").trim();
    if (!body.applicationId) return Response.json({ error: "חסר מזהה מועמדות" }, { status: 400 });
    if (rawText.length < 50) return Response.json({ error: "חומר הגלם קצר מדי. יש להדביק תמלול או הערות מפורטות יותר." }, { status: 400 });
    if (rawText.length > 150000) return Response.json({ error: "חומר הגלם ארוך מדי. המגבלה היא 150,000 תווים." }, { status: 400 });

    const env = await getEnv();
    if (!env.OPENAI_API_KEY) return Response.json({ error: "מנוע ה-AI טרם הופעל" }, { status: 503 });
    const row = await env.DB.prepare(
      `SELECT a.id,c.full_name,c.professional_title,c.company,c.experience_summary,c.recruiter_opinion,c.cv_extracted_text,
      j.title,j.client,j.description,j.must_requirements,j.preferred_requirements,j.technologies,j.min_years,j.professional_emphasis,j.personality_emphasis
      FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN jobs j ON j.id=a.job_id
      WHERE a.id=? AND a.archived=0 AND c.archived=0 AND j.archived=0`,
    ).bind(body.applicationId).first<Record<string, unknown>>();
    if (!row) return Response.json({ error: "המועמדות לא נמצאה" }, { status: 404 });

    const saved = await env.DB.prepare("SELECT content FROM ai_instructions WHERE key='interview_summary'")
      .first<{ content: string }>().catch(() => null);
    const input = `המשרה:\nשם: ${row.title}\nלקוח: ${row.client}\nתיאור: ${row.description}\nדרישות חובה: ${row.must_requirements}\nדרישות יתרון: ${row.preferred_requirements}\nטכנולוגיות: ${row.technologies}\nשנות ניסיון: ${row.min_years ?? "לא הוגדר"}\nדגשים מקצועיים: ${row.professional_emphasis}\nדגשים אישיותיים: ${row.personality_emphasis}\n\nהמועמד:\nשם: ${row.full_name}\nתפקיד מקצועי: ${row.professional_title || "לא ידוע"}\nחברה: ${row.company || "לא ידוע"}\nתקציר בכרטיס: ${row.experience_summary || "לא הוזן"}\n\nחוות דעת מגייס מהראיון הראשוני:\n${row.recruiter_opinion || "לא הוזנה"}\n\nקורות חיים כמקור משלים בלבד:\n${String(row.cv_extracted_text || "לא צורפו").slice(0, 80000)}\n\nחומר גלם מהראיון:\n${rawText}`;
    const model = String(env.OPENAI_MODEL || "gpt-5.6-terra");
    const aiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model, store: false, reasoning: { effort: "medium" },
        instructions: saved?.content || INTERVIEW_SUMMARY_INSTRUCTIONS,
        input,
        text: { verbosity: "medium", format: { type: "json_schema", name: "interview_summary", strict: true, schema: summarySchema } },
      }),
    });
    const raw = (await aiResponse.json()) as Record<string, unknown>;
    if (!aiResponse.ok) return Response.json({ error: `שגיאת OpenAI: ${String((raw.error as Record<string, unknown> | undefined)?.message || aiResponse.status)}` }, { status: 502 });
    const outputItems = Array.isArray(raw.output) ? raw.output as Array<Record<string, unknown>> : [];
    const outputText = String(raw.output_text || outputItems.flatMap((item) => Array.isArray(item.content) ? item.content as Array<Record<string, unknown>> : []).find((content) => content.type === "output_text")?.text || "");
    if (!outputText) return Response.json({ error: "המודל לא החזיר טיוטה" }, { status: 502 });
    const draft = JSON.parse(outputText) as { summary: string; uncertainties: string[] };
    const usage = usageAndCost(raw, model);
    await env.DB.prepare(`INSERT INTO ai_activity_logs (action_type,subject_type,subject_id,subject_label,model,input_tokens,cached_input_tokens,output_tokens,estimated_cost_usd) VALUES (?,?,?,?,?,?,?,?,?)`)
      .bind("יצירת טיוטת סיכום ראיון", "application", body.applicationId, `${row.full_name} · ${row.title} · ${row.client}`, model, usage.input, usage.cached, usage.output, usage.cost).run();
    return Response.json({ draft, usage });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "יצירת הסיכום נכשלה" }, { status: 500 });
  }
}
import { requireAppIdentity } from "../../../../lib/app-auth";
