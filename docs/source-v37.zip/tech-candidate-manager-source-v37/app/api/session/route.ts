import { getAppIdentity } from "../../../lib/app-auth";

function decodeDisplayName(request: Request) {
  const value = request.headers.get("oai-authenticated-user-full-name") || "";
  const encoding = request.headers.get("oai-authenticated-user-full-name-encoding");
  if (!value || encoding !== "percent-encoded-utf-8") return "";
  try {
    return decodeURIComponent(value);
  } catch {
    return "";
  }
}

export async function GET(request: Request) {
  const email = (request.headers.get("oai-authenticated-user-email") || "").trim().toLowerCase();
  const identity = await getAppIdentity(request);
  return Response.json({
    email,
    name: decodeDisplayName(request) || email,
    isAuthenticated: Boolean(email),
    isAllowed: Boolean(identity),
    isAdmin: identity?.role === "admin",
  });
}
