async function getDatabase(): Promise<D1Database> {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("Database binding is unavailable");
  return env.DB;
}

const demoJobs = [
  [
    "Data Engineer",
    "אלפא תעופה",
    "פעילה",
    "פיתוח והובלת תהליכי Data ארגוניים, אינטגרציות ומידול נתונים בסביבת Enterprise.",
    "ניסיון בפיתוח ETL/ELT, עבודה משמעותית עם Spark ו-Python, SQL ברמה גבוהה וניסיון ב-Production.",
    '["Databricks","Spark","Python","SQL"]',
    "עומק מעשי ב-Spark, אחריות מקצה לקצה ויכולת עבודה מול גורמים עסקיים וטכנולוגיים.",
  ],
  [
    "Data Platforms Administrator",
    "מדיקל מערכות",
    "פעילה",
    "אחריות תשתיתית על פלטפורמות Data וקלסטרים ארגוניים.",
    "Linux חזק, התקנה וקינפוג של מערכות, ניסיון תפעולי ב-Kafka ופתרון תקלות Production.",
    '["Kafka","Linux","Ansible","Trino"]',
    "Platform ownership ולא שימוש אפליקטיבי בלבד.",
  ],
  [
    "Machine Learning Engineer",
    "בנק דלתא",
    "בהשהיה",
    "העברת מודלי ML ל-Production ופיתוח תשתיות MLOps.",
    "Python, Containers, Kubernetes, CI/CD וניסיון בפריסת שירותי מודלים.",
    '["Python","Kubernetes","MLflow","GCP"]',
    "יכולת פיתוח לצד הבנה תשתיתית ו-Production mindset.",
  ],
];

const demoCandidates = [
  [
    "נועה לוין",
    "FinCloud",
    7,
    '["Python","PySpark","Kafka","AWS"]',
    1,
    "מיועדת לראיון",
    "2026-08-13T10:00",
    88,
    "מתאימה מאוד",
    "ראיון מקצועי",
  ],
  [
    "אורי ברק",
    "InfraOps",
    9,
    '["Linux","Kafka","Ansible","Kubernetes"]',
    2,
    "דורש בירור",
    null,
    82,
    "מתאים בכפוף לבירור",
    "בירור ניסיון Kafka תשתיתי",
  ],
  [
    "מיכל כהן",
    "VisionAI",
    5,
    '["Python","MLflow","GCP","Docker"]',
    3,
    "ראיון בוצע",
    "2026-08-10",
    79,
    "מתאימה",
    "החלטה לאחר ראיון",
  ],
  [
    "רועי שלו",
    "DataWorks",
    4,
    '["SQL","Databricks","Airflow"]',
    1,
    "בבדיקה",
    null,
    73,
    "מתאים בכפוף לבירור",
    "השלמת הערכה",
  ],
  [
    "דנה פרץ",
    "Retail BI",
    3,
    '["SQL","ETL","Azure"]',
    1,
    "חדש",
    null,
    65,
    "התאמה חלקית",
    "בדיקת קורות חיים",
  ],
  [
    "יואב רז",
    "CloudBase",
    4,
    '["DevOps","Linux","Docker"]',
    2,
    "בבדיקה",
    "2026-08-14",
    58,
    "התאמה חלקית",
    "ראיון מקצועי",
  ],
  [
    "ליאור גל",
    "WebStack",
    2,
    '["Python","FastAPI","AWS"]',
    3,
    "נדחה",
    "2026-08-06",
    46,
    "לא מתאים",
    "",
  ],
  [
    "תמר ישראלי",
    "GlobalPay",
    8,
    '["Spark","Python","Hadoop","Kafka"]',
    1,
    "הועברה ללקוח",
    "2026-08-05",
    84,
    "מתאימה מאוד",
    "מעקב מול לקוח",
  ],
  [
    "עמית מור",
    "Enterprise IT",
    6,
    '["Linux","Elastic","Ansible"]',
    2,
    "חדש",
    null,
    76,
    "מתאים",
    "בדיקת קורות חיים",
  ],
];

async function ensureSchema(db: D1Database) {
  await db.batch([
    db.prepare(
      `CREATE TABLE IF NOT EXISTS jobs (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,client TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'פעילה',description TEXT NOT NULL DEFAULT '',must_requirements TEXT NOT NULL DEFAULT '',preferred_requirements TEXT NOT NULL DEFAULT '',technologies TEXT NOT NULL DEFAULT '[]',min_years INTEGER,professional_emphasis TEXT NOT NULL DEFAULT '',personality_emphasis TEXT NOT NULL DEFAULT '',internal_notes TEXT NOT NULL DEFAULT '',archived INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS candidates (id INTEGER PRIMARY KEY AUTOINCREMENT,full_name TEXT NOT NULL,phone TEXT NOT NULL DEFAULT '',email TEXT NOT NULL DEFAULT '',linkedin_url TEXT NOT NULL DEFAULT '',professional_title TEXT NOT NULL DEFAULT '',company TEXT NOT NULL DEFAULT '',years_experience INTEGER,technologies TEXT NOT NULL DEFAULT '[]',experience_summary TEXT NOT NULL DEFAULT '',recruiter_opinion TEXT NOT NULL DEFAULT '',archived INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS applications (id INTEGER PRIMARY KEY AUTOINCREMENT,candidate_id INTEGER NOT NULL,job_id INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'חדש',interview_date TEXT,interview_summary TEXT NOT NULL DEFAULT '',next_action TEXT NOT NULL DEFAULT '',next_action_date TEXT,score INTEGER,recommendation TEXT NOT NULL DEFAULT 'טרם הוערך',evaluation_type TEXT NOT NULL DEFAULT 'ראשונית',evaluation_date TEXT,evaluation_json TEXT,evaluation_feedback TEXT NOT NULL DEFAULT '',proposed_engine_rule TEXT NOT NULL DEFAULT '',engine_rule_status TEXT NOT NULL DEFAULT 'ללא הצעה',cv_key TEXT,cv_filename TEXT,cv_content_type TEXT,cv_size INTEGER,cv_pages INTEGER,cv_extracted_text TEXT NOT NULL DEFAULT '',cv_extraction_status TEXT NOT NULL DEFAULT 'לא הועלה',cv_uploaded_at TEXT,archived INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(candidate_id) REFERENCES candidates(id),FOREIGN KEY(job_id) REFERENCES jobs(id))`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS ai_activity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,action_type TEXT NOT NULL,subject_type TEXT NOT NULL DEFAULT '',subject_id INTEGER,subject_label TEXT NOT NULL DEFAULT '',model TEXT NOT NULL,input_tokens INTEGER NOT NULL DEFAULT 0,cached_input_tokens INTEGER NOT NULL DEFAULT 0,output_tokens INTEGER NOT NULL DEFAULT 0,estimated_cost_usd REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS evaluation_rules (id INTEGER PRIMARY KEY AUTOINCREMENT,rule_text TEXT NOT NULL UNIQUE,source_application_id INTEGER,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS ai_instructions (key TEXT PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL,content TEXT NOT NULL,is_custom INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS app_users (email TEXT PRIMARY KEY,role TEXT NOT NULL DEFAULT 'user',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    ),
  ]);
  await db.prepare("INSERT OR IGNORE INTO app_users (email,role) VALUES (?,'admin')")
    .bind("matanya111@googlemail.com").run();
  const defaults: Record<string, string> = {
    candidate_evaluation: EVALUATION_INSTRUCTIONS,
    post_interview_evaluation: POST_INTERVIEW_EVALUATION_INSTRUCTIONS,
    job_parsing: JOB_PARSING_INSTRUCTIONS,
    cv_extraction: CV_EXTRACTION_INSTRUCTIONS,
    interview_summary: INTERVIEW_SUMMARY_INSTRUCTIONS,
  };
  for (const definition of instructionDefinitions) {
    await db.prepare(
      "INSERT OR IGNORE INTO ai_instructions (key,title,description,content) VALUES (?,?,?,?)",
    ).bind(definition.key, definition.title, definition.description, defaults[definition.key]).run();
    await db.prepare(
      "UPDATE ai_instructions SET title=?,description=?,content=?,updated_at=CURRENT_TIMESTAMP WHERE key=? AND is_custom=0 AND content<>?",
    ).bind(definition.title, definition.description, defaults[definition.key], definition.key, defaults[definition.key]).run();
  }
  const columns = await db
    .prepare("PRAGMA table_info(applications)")
    .all<{ name: string }>();
  if (!columns.results.some((column) => column.name === "evaluation_json"))
    await db
      .prepare("ALTER TABLE applications ADD COLUMN evaluation_json TEXT")
      .run();
  if (!columns.results.some((column) => column.name === "evaluation_feedback"))
    await db
      .prepare("ALTER TABLE applications ADD COLUMN evaluation_feedback TEXT NOT NULL DEFAULT ''")
      .run();
  if (!columns.results.some((column) => column.name === "proposed_engine_rule"))
    await db.prepare("ALTER TABLE applications ADD COLUMN proposed_engine_rule TEXT NOT NULL DEFAULT ''").run();
  if (!columns.results.some((column) => column.name === "engine_rule_status"))
    await db.prepare("ALTER TABLE applications ADD COLUMN engine_rule_status TEXT NOT NULL DEFAULT 'ללא הצעה'").run();
  const candidateColumns = await db
    .prepare("PRAGMA table_info(candidates)")
    .all<{ name: string }>();
  const candidateCvColumns: [string, string][] = [
    ["professional_title", "TEXT NOT NULL DEFAULT ''"],
    ["recruiter_opinion", "TEXT NOT NULL DEFAULT ''"],
    ["cv_key", "TEXT"],
    ["cv_filename", "TEXT"],
    ["cv_content_type", "TEXT"],
    ["cv_size", "INTEGER"],
    ["cv_pages", "INTEGER"],
    ["cv_extracted_text", "TEXT NOT NULL DEFAULT ''"],
    ["cv_extraction_status", "TEXT NOT NULL DEFAULT 'לא הועלה'"],
    ["cv_uploaded_at", "TEXT"],
  ];
  for (const [name, type] of candidateCvColumns)
    if (!candidateColumns.results.some((column) => column.name === name))
      await db
        .prepare(`ALTER TABLE candidates ADD COLUMN ${name} ${type}`)
        .run();
  await db
    .prepare(
      `UPDATE candidates SET
    cv_key=COALESCE(cv_key,(SELECT cv_key FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1)),
    cv_filename=COALESCE(cv_filename,(SELECT cv_filename FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1)),
    cv_content_type=COALESCE(cv_content_type,(SELECT cv_content_type FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1)),
    cv_size=COALESCE(cv_size,(SELECT cv_size FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1)),
    cv_pages=COALESCE(cv_pages,(SELECT cv_pages FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1)),
    cv_extracted_text=CASE WHEN LENGTH(COALESCE(cv_extracted_text,''))=0 THEN COALESCE((SELECT cv_extracted_text FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1),'') ELSE cv_extracted_text END,
    cv_extraction_status=CASE WHEN cv_extraction_status='לא הועלה' THEN COALESCE((SELECT cv_extraction_status FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1),'לא הועלה') ELSE cv_extraction_status END,
    cv_uploaded_at=COALESCE(cv_uploaded_at,(SELECT cv_uploaded_at FROM applications a WHERE a.candidate_id=candidates.id AND a.cv_key IS NOT NULL ORDER BY a.cv_uploaded_at DESC LIMIT 1))`,
    )
    .run();
}

async function seedIfEmpty() {
  const db = await getDatabase();
  await ensureSchema(db);
  const count = await db
    .prepare("SELECT COUNT(*) AS count FROM jobs")
    .first<{ count: number }>();
  if ((count?.count ?? 0) > 0) return;
  for (const j of demoJobs)
    await db
      .prepare(
        "INSERT INTO jobs (title,client,status,description,must_requirements,technologies,professional_emphasis) VALUES (?,?,?,?,?,?,?)",
      )
      .bind(...j)
      .run();
  for (const c of demoCandidates) {
    const inserted = await db
      .prepare(
        "INSERT INTO candidates (full_name,company,years_experience,technologies,experience_summary) VALUES (?,?,?,?,?)",
      )
      .bind(
        c[0],
        c[1],
        c[2],
        c[3],
        `${c[0]} בעל/ת ניסיון מעשי בסביבות Data ו-Production.`,
      )
      .run();
    await db
      .prepare(
        "INSERT INTO applications (candidate_id,job_id,status,interview_date,score,recommendation,next_action,evaluation_date) VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
      )
      .bind(inserted.meta.last_row_id, c[4], c[5], c[6], c[7], c[8], c[9])
      .run();
  }
  await db
    .prepare(
      "UPDATE applications SET interview_summary = ? WHERE candidate_id = 3",
    )
    .bind(
      "המועמדת הציגה ניסיון מעשי בתהליכי Data מורכבים. התקשורת הייתה ברורה ומסודרת.",
    )
    .run();
}

async function cleanupDemoDataOnce() {
  const { env } = await import("cloudflare:workers");
  const db = env.DB;
  if (!db) return;
  await db.prepare(`CREATE TABLE IF NOT EXISTS system_migrations (key TEXT PRIMARY KEY,completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const done = await db.prepare(`SELECT key FROM system_migrations WHERE key='keep_vladimir_maccabi_platform_v2'`).first();
  if (done) return;
  const candidate = await db.prepare(`SELECT id,full_name,cv_key FROM candidates WHERE LOWER(full_name) LIKE '%vladimir%' OR full_name LIKE '%ולדימיר%' ORDER BY updated_at DESC LIMIT 1`).first<{ id: number; full_name: string; cv_key: string | null }>();
  if (!candidate) return;
  const job = await db.prepare(`SELECT id FROM jobs WHERE (client LIKE '%מכבי%' OR LOWER(client) LIKE '%maccabi%') AND LOWER(title) LIKE '%platform%' ORDER BY updated_at DESC LIMIT 1`).first<{ id: number }>();
  if (!job) return;
  const application = await db.prepare(`SELECT id FROM applications WHERE candidate_id=? AND job_id=? ORDER BY updated_at DESC LIMIT 1`).bind(candidate.id, job.id).first<{ id: number }>();
  if (!application) return;
  const applicationId = application.id, jobId = job.id;
  const removedFiles = await db.prepare(`SELECT cv_key FROM candidates WHERE id<>? AND cv_key IS NOT NULL`).bind(candidate.id).all<{ cv_key: string }>();
  await db.batch([
    db.prepare(`DELETE FROM applications WHERE id<>?`).bind(applicationId),
    db.prepare(`DELETE FROM candidates WHERE id<>?`).bind(candidate.id),
    db.prepare(`DELETE FROM jobs WHERE id<>?`).bind(jobId),
    db.prepare(`DELETE FROM ai_activity_logs WHERE NOT (subject_type='application' AND subject_id=?) AND NOT (subject_label LIKE '%Vladimir%' OR subject_label LIKE '%ולדימיר%' OR subject_label LIKE '%מכבי%')`).bind(applicationId),
    db.prepare(`INSERT INTO system_migrations (key) VALUES ('keep_vladimir_maccabi_platform_v2')`),
  ]);
  if (env.BUCKET)
    for (const file of removedFiles.results)
      await env.BUCKET.delete(file.cv_key).catch(() => undefined);
}

const DEFAULT_ADMIN_EMAILS = ["matanya111@googlemail.com"];

async function isAdminRequest(request: Request) {
  return (await getAppIdentity(request))?.role === "admin";
}

export async function GET(request: Request) {
  try {
    const identity = await requireAppIdentity(request);
    if (identity instanceof Response) return identity;
    await seedIfEmpty();
    await cleanupDemoDataOnce();
    const db = await getDatabase();
    await db.prepare(`UPDATE applications SET next_action=CASE
      WHEN LENGTH(TRIM(interview_summary))>0 AND evaluation_type<>'לאחר ראיון' THEN 'הפעלת הערכה סופית לאחר ראיון'
      WHEN LENGTH(TRIM(interview_summary))>0 AND evaluation_type='לאחר ראיון' THEN 'קבלת החלטה ועדכון סטטוס'
      WHEN evaluation_date IS NULL AND EXISTS (SELECT 1 FROM candidates c WHERE c.id=applications.candidate_id AND LENGTH(COALESCE(c.cv_extracted_text,''))>0) THEN 'הפעלת הערכת התאמה ראשונית'
      WHEN evaluation_date IS NOT NULL AND LENGTH(TRIM(interview_summary))=0 THEN 'תיאום או ביצוע ראיון מקצועי'
      ELSE next_action END
      WHERE next_action IN ('בדיקת קורות חיים','השלמת הערכה','אימות פרטי קורות חיים')`).run();
    const jobs = await db
      .prepare(
        `SELECT j.*, COUNT(CASE WHEN a.archived=0 THEN 1 END) candidates_count,
      SUM(CASE WHEN a.score >= 75 AND a.recommendation IN ('מתאים','מתאימה','מתאים מאוד','מתאימה מאוד') AND a.archived = 0 THEN 1 ELSE 0 END) high_fit_count,
      SUM(CASE WHEN a.score BETWEEN 60 AND 74 AND a.recommendation NOT IN ('לא מתאים','לא מתאימה','לא רלוונטי לתפקיד') AND a.archived = 0 THEN 1 ELSE 0 END) reasonable_fit_count
      FROM jobs j LEFT JOIN applications a ON a.job_id=j.id WHERE j.archived=0 GROUP BY j.id ORDER BY j.updated_at DESC`,
      )
      .all();
    const candidates = await db
      .prepare(
        `SELECT c.*,c.created_at candidate_created_at,a.updated_at application_updated_at,a.id application_id,a.job_id,a.status,a.interview_date,a.interview_summary,a.next_action,a.next_action_date,a.score,a.recommendation,a.evaluation_type,a.evaluation_date,a.evaluation_json,a.evaluation_feedback,a.proposed_engine_rule,a.engine_rule_status,LENGTH(c.cv_extracted_text) cv_text_length,j.title role,j.client
      FROM candidates c JOIN applications a ON a.candidate_id=c.id JOIN jobs j ON j.id=a.job_id
      WHERE c.archived=0 AND a.archived=0 AND j.archived=0 ORDER BY a.updated_at DESC`,
      )
      .all();
    const archivedJobs = await db
      .prepare(`SELECT id,title,client,status,updated_at FROM jobs WHERE archived=1 ORDER BY updated_at DESC`)
      .all();
    const archivedApplications = await db
      .prepare(`SELECT a.id application_id,a.status,a.updated_at,c.full_name,j.title role,j.client
        FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN jobs j ON j.id=a.job_id
        WHERE a.archived=1 AND c.archived=0 AND j.archived=0 ORDER BY a.updated_at DESC`)
      .all();
    const aiActivity = await db
      .prepare(`SELECT * FROM ai_activity_logs ORDER BY created_at DESC LIMIT 100`)
      .all();
    const aiInstructions = (await isAdminRequest(request))
      ? await db.prepare("SELECT key,title,description,content,is_custom,updated_at FROM ai_instructions ORDER BY CASE key WHEN 'candidate_evaluation' THEN 1 WHEN 'post_interview_evaluation' THEN 2 WHEN 'interview_summary' THEN 3 WHEN 'job_parsing' THEN 4 ELSE 5 END").all()
      : { results: [] };
    const appUsers = (await isAdminRequest(request))
      ? await db.prepare("SELECT email,role,created_at,updated_at FROM app_users ORDER BY CASE role WHEN 'admin' THEN 1 ELSE 2 END,email").all()
      : { results: [] };
    return Response.json({
      jobs: jobs.results,
      candidates: candidates.results,
      archivedJobs: archivedJobs.results,
      archivedApplications: archivedApplications.results,
      aiActivity: aiActivity.results,
      aiInstructions: aiInstructions.results,
      appUsers: appUsers.results,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Database error" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const identity = await requireAppIdentity(request);
    if (identity instanceof Response) return identity;
    const db = await getDatabase();
    const body = (await request.json()) as Record<string, unknown>;
    if (body.entity === "job") {
      const result = await db
        .prepare(
          `INSERT INTO jobs (title,client,status,description,must_requirements,preferred_requirements,technologies,min_years,professional_emphasis,personality_emphasis,internal_notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        )
        .bind(
          body.title,
          body.client,
          body.status ?? "פעילה",
          body.description ?? "",
          body.mustRequirements ?? "",
          body.preferredRequirements ?? "",
          JSON.stringify(body.technologies ?? []),
          body.minYears ?? null,
          body.professionalEmphasis ?? "",
          body.personalityEmphasis ?? "",
          body.internalNotes ?? "",
        )
        .run();
      return Response.json({ id: result.meta.last_row_id }, { status: 201 });
    }
    if (body.entity === "candidate") {
      const result = await db
        .prepare(
          `INSERT INTO candidates (full_name,phone,email,linkedin_url,professional_title,company,years_experience,technologies,experience_summary) VALUES (?,?,?,?,?,?,?,?,?)`,
        )
        .bind(
          body.fullName,
          body.phone ?? "",
          body.email ?? "",
          body.linkedinUrl ?? "",
          body.professionalTitle ?? "",
          body.company ?? "",
          body.yearsExperience ?? null,
          JSON.stringify(body.technologies ?? []),
          body.experienceSummary ?? "",
        )
        .run();
      await db
        .prepare(
          `INSERT INTO applications (candidate_id,job_id,status,next_action) VALUES (?,?,?,?)`,
        )
        .bind(
          result.meta.last_row_id,
          body.jobId,
          body.status ?? "חדש",
          body.nextAction ?? "בדיקת קורות חיים",
        )
        .run();
      return Response.json({ id: result.meta.last_row_id }, { status: 201 });
    }
    if (body.entity === "application") {
      const candidateId = Number(body.candidateId),
        jobId = Number(body.jobId);
      const candidate = await db
        .prepare("SELECT id FROM candidates WHERE id=? AND archived=0")
        .bind(candidateId)
        .first();
      const job = await db
        .prepare("SELECT id FROM jobs WHERE id=? AND archived=0")
        .bind(jobId)
        .first();
      if (!candidate || !job)
        return Response.json(
          { error: "המועמד או המשרה אינם זמינים" },
          { status: 404 },
        );
      const existing = await db
        .prepare(
          "SELECT id FROM applications WHERE candidate_id=? AND job_id=? AND archived=0",
        )
        .bind(candidateId, jobId)
        .first<{ id: number }>();
      if (existing)
        return Response.json(
          { error: "המועמד כבר משויך למשרה הזאת" },
          { status: 409 },
        );
      const result = await db
        .prepare(
          "INSERT INTO applications (candidate_id,job_id,status,next_action) VALUES (?,?,'חדש','בדיקת קורות חיים')",
        )
        .bind(candidateId, jobId)
        .run();
      return Response.json(
        { applicationId: result.meta.last_row_id },
        { status: 201 },
      );
    }
    if (body.entity === "aiInstruction") {
      if (!(await isAdminRequest(request)))
        return Response.json({ error: "הפעולה מותרת למנהל המערכת בלבד" }, { status: 403 });
      const key = String(body.key || "");
      const defaults: Record<string, string> = {
        candidate_evaluation: EVALUATION_INSTRUCTIONS,
        post_interview_evaluation: POST_INTERVIEW_EVALUATION_INSTRUCTIONS,
        job_parsing: JOB_PARSING_INSTRUCTIONS,
        cv_extraction: CV_EXTRACTION_INSTRUCTIONS,
        interview_summary: INTERVIEW_SUMMARY_INSTRUCTIONS,
      };
      if (!(key in defaults))
        return Response.json({ error: "סוג ההוראות אינו מוכר" }, { status: 400 });
      const content = body.reset ? defaults[key] : String(body.content || "").trim();
      if (content.length < 50)
        return Response.json({ error: "ההוראות קצרות מדי ועלולות לגרום לתוצאות לא תקינות" }, { status: 400 });
      await db.prepare("UPDATE ai_instructions SET content=?,is_custom=?,updated_at=CURRENT_TIMESTAMP WHERE key=?")
        .bind(content, body.reset ? 0 : 1, key).run();
      return Response.json({ ok: true });
    }
    if (body.entity === "appUser") {
      if (!(await isAdminRequest(request)))
        return Response.json({ error: "הפעולה מותרת למנהל המערכת בלבד" }, { status: 403 });
      const email = String(body.email || "").trim().toLowerCase();
      const role = String(body.role || "user");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return Response.json({ error: "יש להזין כתובת מייל תקינה" }, { status: 400 });
      if (!['admin','user'].includes(role))
        return Response.json({ error: "תפקיד המשתמש אינו תקין" }, { status: 400 });
      await db.prepare(`INSERT INTO app_users (email,role) VALUES (?,?)
        ON CONFLICT(email) DO UPDATE SET role=excluded.role,updated_at=CURRENT_TIMESTAMP`).bind(email, role).run();
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unsupported entity" }, { status: 400 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Database error" },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const identity = await requireAppIdentity(request);
    if (identity instanceof Response) return identity;
    const db = await getDatabase();
    const body = (await request.json()) as Record<string, unknown>;
    if (body.entity === "aiInstruction") {
      if (!(await isAdminRequest(request)))
        return Response.json({ error: "הפעולה מותרת למנהל המערכת בלבד" }, { status: 403 });
      const key = String(body.key || "");
      const defaults: Record<string, string> = {
        candidate_evaluation: EVALUATION_INSTRUCTIONS,
        post_interview_evaluation: POST_INTERVIEW_EVALUATION_INSTRUCTIONS,
        job_parsing: JOB_PARSING_INSTRUCTIONS,
        cv_extraction: CV_EXTRACTION_INSTRUCTIONS,
        interview_summary: INTERVIEW_SUMMARY_INSTRUCTIONS,
      };
      if (!(key in defaults))
        return Response.json({ error: "סוג ההוראות אינו מוכר" }, { status: 400 });
      const content = body.reset ? defaults[key] : String(body.content || "").trim();
      if (content.length < 50)
        return Response.json({ error: "ההוראות קצרות מדי ועלולות לגרום לתוצאות לא תקינות" }, { status: 400 });
      await db.prepare("UPDATE ai_instructions SET content=?,is_custom=?,updated_at=CURRENT_TIMESTAMP WHERE key=?")
        .bind(content, body.reset ? 0 : 1, key).run();
      return Response.json({ ok: true });
    }
    if (body.entity === "application") {
      if (body.engineRuleDecision === "approve" || body.engineRuleDecision === "reject") {
        const application = await db.prepare("SELECT proposed_engine_rule FROM applications WHERE id=?").bind(body.id).first<{ proposed_engine_rule: string }>();
        if (!application?.proposed_engine_rule)
          return Response.json({ error: "לא נמצאה הצעה רוחבית לאישור" }, { status: 404 });
        if (body.engineRuleDecision === "approve")
          await db.prepare("INSERT OR IGNORE INTO evaluation_rules (rule_text,source_application_id) VALUES (?,?)").bind(application.proposed_engine_rule, body.id).run();
        await db.prepare("UPDATE applications SET engine_rule_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(body.engineRuleDecision === "approve" ? "אושר ככלל קבוע" : "נדחה", body.id).run();
        return Response.json({ ok: true });
      }
      const fields: string[] = [];
      const values: unknown[] = [];
      const map: Record<string, string> = {
        status: "status",
        interviewSummary: "interview_summary",
        interviewDate: "interview_date",
        nextAction: "next_action",
        nextActionDate: "next_action_date",
        archived: "archived",
      };
      for (const [key, column] of Object.entries(map))
        if (key in body) {
          fields.push(`${column}=?`);
          values.push(body[key]);
        }
      if (!("status" in body) && "interviewDate" in body && body.interviewDate) {
        fields.push("status=CASE WHEN status IN ('חדש','בבדיקה','דורש בירור') THEN 'מיועד לראיון' ELSE status END");
      }
      if (!("status" in body) && "interviewSummary" in body && String(body.interviewSummary || "").trim()) {
        fields.push("status=CASE WHEN status IN ('חדש','בבדיקה','דורש בירור','מיועד לראיון') THEN 'ראיון בוצע' ELSE status END");
      }
      fields.push("updated_at=CURRENT_TIMESTAMP");
      values.push(body.id);
      await db
        .prepare(`UPDATE applications SET ${fields.join(",")} WHERE id=?`)
        .bind(...values)
        .run();
      return Response.json({ ok: true });
    }
    if (body.entity === "candidate") {
      const fields: string[] = [];
      const values: unknown[] = [];
      const map: Record<string, string> = {
        fullName: "full_name",
        phone: "phone",
        email: "email",
        linkedinUrl: "linkedin_url",
        professionalTitle: "professional_title",
        company: "company",
        yearsExperience: "years_experience",
        experienceSummary: "experience_summary",
        recruiterOpinion: "recruiter_opinion",
      };
      for (const [key, column] of Object.entries(map))
        if (key in body) {
          fields.push(`${column}=?`);
          values.push(body[key]);
        }
      if ("technologies" in body) {
        fields.push("technologies=?");
        values.push(JSON.stringify(body.technologies ?? []));
      }
      if (!fields.length)
        return Response.json(
          { error: "לא נשלחו שדות לעדכון" },
          { status: 400 },
        );
      fields.push("updated_at=CURRENT_TIMESTAMP");
      values.push(body.id);
      await db
        .prepare(`UPDATE candidates SET ${fields.join(",")} WHERE id=?`)
        .bind(...values)
        .run();
      return Response.json({ ok: true });
    }
    if (body.entity === "job") {
      const fields: string[] = [];
      const values: unknown[] = [];
      const map: Record<string, string> = {
        title: "title",
        client: "client",
        status: "status",
        description: "description",
        mustRequirements: "must_requirements",
        preferredRequirements: "preferred_requirements",
        minYears: "min_years",
        professionalEmphasis: "professional_emphasis",
        personalityEmphasis: "personality_emphasis",
        internalNotes: "internal_notes",
        archived: "archived",
      };
      for (const [key, column] of Object.entries(map))
        if (key in body) {
          fields.push(`${column}=?`);
          values.push(body[key]);
        }
      if ("technologies" in body) {
        fields.push("technologies=?");
        values.push(JSON.stringify(body.technologies ?? []));
      }
      fields.push("updated_at=CURRENT_TIMESTAMP");
      values.push(body.id);
      await db
        .prepare(`UPDATE jobs SET ${fields.join(",")} WHERE id=?`)
        .bind(...values)
        .run();
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unsupported entity" }, { status: 400 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Database error" },
      { status: 500 },
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const identity = await requireAppIdentity(request);
    if (identity instanceof Response) return identity;
    const { env } = await import("cloudflare:workers");
    const db = env.DB;
    if (!db) throw new Error("Database binding is unavailable");
    const body = (await request.json()) as Record<string, unknown>;
    if (body.entity === "appUser") {
      if (!(await isAdminRequest(request)))
        return Response.json({ error: "הפעולה מותרת למנהל המערכת בלבד" }, { status: 403 });
      const email = String(body.email || "").trim().toLowerCase();
      if (DEFAULT_ADMIN_EMAILS.includes(email))
        return Response.json({ error: "לא ניתן להסיר את מנהל המערכת הראשי" }, { status: 400 });
      await db.prepare("DELETE FROM app_users WHERE email=?").bind(email).run();
      return Response.json({ ok: true });
    }
    const id = Number(body.id);
    if (!id) return Response.json({ error: "חסר מזהה למחיקה" }, { status: 400 });
    if (body.entity === "job") {
      const count = await db.prepare("SELECT COUNT(*) count FROM applications WHERE job_id=?").bind(id).first<{ count: number }>();
      if ((count?.count || 0) > 0) return Response.json({ error: "לא ניתן למחוק משרה שיש לה מועמדויות. ניתן להעביר אותה לארכיון." }, { status: 409 });
      await db.prepare("DELETE FROM jobs WHERE id=?").bind(id).run();
      return Response.json({ ok: true });
    }
    if (body.entity === "candidate") {
      const candidate = await db.prepare("SELECT cv_key FROM candidates WHERE id=?").bind(id).first<{ cv_key: string | null }>();
      if (!candidate) return Response.json({ error: "המועמד לא נמצא" }, { status: 404 });
      await db.batch([
        db.prepare("DELETE FROM applications WHERE candidate_id=?").bind(id),
        db.prepare("DELETE FROM candidates WHERE id=?").bind(id),
      ]);
      if (candidate.cv_key && env.BUCKET) await env.BUCKET.delete(candidate.cv_key).catch(() => undefined);
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unsupported entity" }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "המחיקה נכשלה" }, { status: 500 });
  }
}
import { EVALUATION_INSTRUCTIONS, POST_INTERVIEW_EVALUATION_INSTRUCTIONS } from "../../../lib/evaluation-prompt";
import { CV_EXTRACTION_INSTRUCTIONS, INTERVIEW_SUMMARY_INSTRUCTIONS, JOB_PARSING_INSTRUCTIONS, instructionDefinitions } from "../../../lib/ai-instructions";
import { getAppIdentity, requireAppIdentity } from "../../../lib/app-auth";
