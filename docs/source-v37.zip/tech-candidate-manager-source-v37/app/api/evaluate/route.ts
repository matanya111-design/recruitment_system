import {
  EVALUATION_INSTRUCTIONS,
  POST_INTERVIEW_EVALUATION_INSTRUCTIONS,
  evaluationSchema,
} from "../../../lib/evaluation-prompt";

async function getEnv() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("Database binding is unavailable");
  return env;
}

function usageAndCost(raw: Record<string, unknown>, model: string) {
  const usage = (raw.usage || {}) as Record<string, unknown>;
  const input = Number(usage.input_tokens || 0);
  const output = Number(usage.output_tokens || 0);
  const details = (usage.input_tokens_details || {}) as Record<string, unknown>;
  const cached = Number(details.cached_tokens || 0);
  const rates = model.includes("sol")
    ? [5, 0.5, 30]
    : model.includes("luna")
      ? [0.2, 0.02, 1.2]
      : [2, 0.2, 12];
  const cost = ((input - cached) * rates[0] + cached * rates[1] + output * rates[2]) / 1_000_000;
  return { input, output, cached, cost };
}

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const { applicationId, reviewerFeedback } = (await request.json()) as {
      applicationId?: number;
      reviewerFeedback?: string;
    };
    if (!applicationId)
      return Response.json({ error: "חסר מזהה מועמדות" }, { status: 400 });
    const env = await getEnv();
    if (!env.OPENAI_API_KEY)
      return Response.json(
        {
          error: "מנוע ה-AI טרם הופעל - חסר מפתח OpenAI API בהגדרות האתר",
          code: "AI_NOT_CONFIGURED",
        },
        { status: 503 },
      );
    const row = await env.DB.prepare(
      `SELECT a.id,a.status,a.interview_summary,a.evaluation_json previous_evaluation,a.evaluation_type previous_evaluation_type,c.cv_extracted_text,c.full_name,c.professional_title,c.company,c.years_experience,c.technologies,c.experience_summary,c.recruiter_opinion,j.title,j.client,j.description,j.must_requirements,j.preferred_requirements,j.technologies job_technologies,j.min_years,j.professional_emphasis,j.personality_emphasis
      FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN jobs j ON j.id=a.job_id
      WHERE a.id=? AND a.archived=0 AND c.archived=0 AND j.archived=0`,
    )
      .bind(applicationId)
      .first<Record<string, unknown>>();
    if (!row)
      return Response.json({ error: "המועמדות לא נמצאה" }, { status: 404 });
    if (!row.cv_extracted_text)
      return Response.json(
        { error: "לא ניתן להעריך ללא טקסט שחולץ מקורות החיים" },
        { status: 422 },
      );

    const activeRules = await env.DB.prepare(
      "SELECT rule_text FROM evaluation_rules WHERE active=1 ORDER BY created_at ASC",
    ).all<{ rule_text: string }>();
    const approvedRules = activeRules.results.length
      ? `\n\nכללי כיול רוחביים שאושרו על ידי המשתמש:\n${activeRules.results.map((rule, index) => `${index + 1}. ${rule.rule_text}`).join("\n")}`
      : "";
    const instructionKey = row.interview_summary ? "post_interview_evaluation" : "candidate_evaluation";
    const savedInstructions = await env.DB.prepare(
      "SELECT content FROM ai_instructions WHERE key=?",
    ).bind(instructionKey).first<{ content: string }>().catch(() => null);

    let previousCalibration = "";
    if (row.previous_evaluation_type === "ראשונית" && row.previous_evaluation) {
      try {
        const previous = JSON.parse(String(row.previous_evaluation)) as Record<string, unknown>;
        previousCalibration = `\n\nהערכה ראשונית קודמת - לכיול השינוי בלבד, אינה Evidence על המועמד:\nציון: ${previous.score ?? "לא ידוע"}\nסיווג: ${previous.fit_label ?? "לא ידוע"}\nהמלצה: ${previous.recommendation ?? "לא ידוע"}\nשורה תחתונה: ${previous.bottom_line ?? "לא ידוע"}\nיש להסביר את השינוי באמצעות מידע חדש מסיכום הראיון. אין לשמר ציון קודם אם המידע החדש מצדיק שינוי.`;
      } catch {
        previousCalibration = "";
      }
    }

    const evaluationType = row.interview_summary ? "לאחר ראיון" : "ראשונית";
    const decisionStage = evaluationType === "לאחר ראיון"
      ? "שלב לאחר ראיון מקצועי. ההחלטה היא האם להעביר את המועמד ללקוח המגייס. במייל לגיוס חובה לכתוב שורה תחתונה חד-משמעית: להעביר ללקוח או לא להעביר ללקוח. אין לבקש מצוות הגיוס להחליט ואין להמליץ על ראיון שכבר בוצע."
      : "שלב סינון ראשוני לפני ראיון מקצועי. ההחלטה היא האם לזמן את המועמד לראיון מקצועי או לא. בשלב זה אסור להציע שינויים בקורות החיים או לכלול המלצות כאלה במייל לגיוס. חובה להחזיר cv_changes_needed=false ו-cv_change_recommendations כרשימה ריקה.";
    const feedback = String(reviewerFeedback || "").trim().slice(0, 12000);
    const feedbackSection = feedback
      ? `\n\nמשוב מקצועי של המשתמש על ההערכה הקודמת:\n${feedback}`
      : "";
    const input = `מקורות המשרה:\nשם: ${row.title}\nלקוח: ${row.client}\nתיאור: ${row.description}\nדרישות חובה: ${row.must_requirements}\nדרישות יתרון: ${row.preferred_requirements}\nטכנולוגיות: ${row.job_technologies}\nשנות ניסיון: ${row.min_years ?? "לא הוגדר"}\nדגשים מקצועיים: ${row.professional_emphasis}\nדגשים אישיותיים: ${row.personality_emphasis}\n\nמקורות המועמד:\nשם: ${row.full_name}\nתפקיד מקצועי בכרטיס: ${row.professional_title || "לא ידוע"}\nחברה: ${row.company}\nשנות ניסיון בכרטיס: ${row.years_experience ?? "לא ידוע"}\nטכנולוגיות בכרטיס: ${row.technologies}\nתקציר בכרטיס: ${row.experience_summary}\n\nחוות דעת מגייס מהראיון הראשוני - מקור משני ולא מאומת; אין לקבל ממנו מסקנות טכנולוגיות ללא חיזוק:\n${row.recruiter_opinion || "לא הוזנה"}\n\nקורות חיים - טקסט מלא שחולץ:\n${String(row.cv_extracted_text).slice(0, 120000)}\n\nסיכום ראיון מקצועי:\n${row.interview_summary || "טרם התקיים או לא הוזן"}${previousCalibration}${feedbackSection}`;
    const model = String(env.OPENAI_MODEL || "gpt-5.6-terra");
    const aiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        store: false,
        reasoning: { effort: "medium" },
        instructions: `${savedInstructions?.content || (evaluationType === "לאחר ראיון" ? POST_INTERVIEW_EVALUATION_INSTRUCTIONS : EVALUATION_INSTRUCTIONS)}${approvedRules}\n\nהשלב הנוכחי מחייב: ${decisionStage}`,
        input,
        text: {
          verbosity: "medium",
          format: {
            type: "json_schema",
            name: "candidate_evaluation",
            strict: true,
            schema: evaluationSchema,
          },
        },
      }),
    });
    const raw = (await aiResponse.json()) as Record<string, unknown>;
    if (!aiResponse.ok)
      return Response.json(
        {
          error: `שגיאת OpenAI: ${String((raw.error as Record<string, unknown> | undefined)?.message || aiResponse.status)}`,
        },
        { status: 502 },
      );
    const outputItems = Array.isArray(raw.output)
      ? (raw.output as Array<Record<string, unknown>>)
      : [];
    const outputText = String(
      raw.output_text ||
        outputItems
          .flatMap((item) =>
            Array.isArray(item.content)
              ? (item.content as Array<Record<string, unknown>>)
              : [],
          )
          .find((content) => content.type === "output_text")?.text ||
        "",
    );
    if (!outputText)
      return Response.json({ error: "המודל לא החזיר הערכה" }, { status: 502 });
    const evaluation = JSON.parse(outputText) as Record<string, unknown>;
    if (evaluationType === "ראשונית") {
      evaluation.cv_changes_needed = false;
      evaluation.cv_change_recommendations = [];
      evaluation.recruitment_email = String(evaluation.recruitment_email || "")
        .replace(/\n*שינויים מומלצים בקורות החיים[\s\S]*$/u, "")
        .trim();
    }
    const needsClarification = evaluationType === "ראשונית" && (
      /בירור|גבולי/.test(String(evaluation.recommendation || "")) ||
      /בירור|גבולי/.test(String(evaluation.fit_label || "")) ||
      /clarif|uncertain/i.test(String(evaluation.gate_status || ""))
    );
    await env.DB.prepare(
      `UPDATE applications SET score=?,recommendation=?,evaluation_type=?,evaluation_date=CURRENT_TIMESTAMP,evaluation_json=?,evaluation_feedback=?,proposed_engine_rule=?,engine_rule_status=?,next_action=?,status=CASE WHEN ?=1 AND status IN ('חדש','בבדיקה') THEN 'דורש בירור' WHEN ?=0 AND status='חדש' THEN 'בבדיקה' ELSE status END,updated_at=CURRENT_TIMESTAMP WHERE id=?`,
    )
      .bind(
        evaluation.score,
        evaluation.fit_label,
        evaluationType,
        JSON.stringify(evaluation),
        feedback,
        feedback && evaluation.generalizable_feedback ? String(evaluation.proposed_engine_rule || "") : "",
        feedback && evaluation.generalizable_feedback && evaluation.proposed_engine_rule ? "ממתין לאישור" : "ללא הצעה",
        evaluationType === "לאחר ראיון" ? "קבלת החלטה ועדכון סטטוס" : "תיאום או ביצוע ראיון מקצועי",
        needsClarification ? 1 : 0,
        needsClarification ? 1 : 0,
        applicationId,
      )
      .run();
    const usage = usageAndCost(raw, model);
    await env.DB.prepare(
      `INSERT INTO ai_activity_logs (action_type,subject_type,subject_id,subject_label,model,input_tokens,cached_input_tokens,output_tokens,estimated_cost_usd) VALUES (?,?,?,?,?,?,?,?,?)`,
    )
      .bind(
        feedback
          ? "עדכון הערכה לפי משוב מקצועי"
          : evaluationType === "לאחר ראיון" ? "הערכת מועמד לאחר ראיון" : "הערכת מועמד ראשונית",
        "application",
        applicationId,
        `${row.full_name} · ${row.title} · ${row.client}`,
        model,
        usage.input,
        usage.cached,
        usage.output,
        usage.cost,
      )
      .run();
    return Response.json({ evaluation, evaluationType, usage });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "הערכת המועמד נכשלה" },
      { status: 500 },
    );
  }
}
import { requireAppIdentity } from "../../../lib/app-auth";
