const schema = {
  type: "object",
  additionalProperties: false,
  required: ["fullName", "email", "phone", "linkedinUrl", "professionalTitle", "company", "yearsExperience", "technologies", "experienceSummary", "uncertainties"],
  properties: {
    fullName: { type: "string" }, email: { type: "string" }, phone: { type: "string" }, linkedinUrl: { type: "string" },
    professionalTitle: { type: "string" }, company: { type: "string" }, yearsExperience: { type: "integer", minimum: 0 },
    technologies: { type: "array", items: { type: "string" } }, experienceSummary: { type: "string" },
    uncertainties: { type: "array", items: { type: "string" } },
  },
} as const;

function usageAndCost(raw: Record<string, unknown>, model: string) {
  const usage = (raw.usage || {}) as Record<string, unknown>;
  const input = Number(usage.input_tokens || 0), output = Number(usage.output_tokens || 0);
  const cached = Number(((usage.input_tokens_details || {}) as Record<string, unknown>).cached_tokens || 0);
  const rates = model.includes("sol") ? [5, 0.5, 30] : model.includes("luna") ? [0.2, 0.02, 1.2] : [2, 0.2, 12];
  return { input, output, cached, cost: ((input - cached) * rates[0] + cached * rates[1] + output * rates[2]) / 1_000_000 };
}

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const { applicationId } = await request.json() as { applicationId?: number };
    if (!applicationId) return Response.json({ error: "חסר מזהה מועמדות" }, { status: 400 });
    const { env } = await import("cloudflare:workers");
    if (!env.DB) throw new Error("Database binding is unavailable");
    if (!env.OPENAI_API_KEY) return Response.json({ error: "מנוע ה-AI אינו מוגדר באתר" }, { status: 503 });
    const current = await env.DB.prepare(`SELECT c.id,c.full_name,c.phone,c.email,c.linkedin_url,c.professional_title,c.company,c.years_experience,c.technologies,c.experience_summary,c.cv_extracted_text FROM applications a JOIN candidates c ON c.id=a.candidate_id WHERE a.id=? AND a.archived=0 AND c.archived=0`).bind(applicationId).first<Record<string, unknown>>();
    if (!current) return Response.json({ error: "המועמדות לא נמצאה" }, { status: 404 });
    if (!current.cv_extracted_text) return Response.json({ error: "לא נמצא טקסט שחולץ מה-PDF. ייתכן שהקובץ סרוק." }, { status: 422 });
    const model = String(env.OPENAI_MODEL || "gpt-5.6-terra");
    const saved = await env.DB.prepare("SELECT content FROM ai_instructions WHERE key='cv_extraction'").first<{content:string}>().catch(()=>null);
    const instructions = saved?.content || CV_EXTRACTION_INSTRUCTIONS;
    const response = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ model, store: false, reasoning: { effort: "low" }, instructions, input: `פרטים קיימים בכרטיס, לשימוש רק כגיבוי אם ה-CV אינו משנה אותם:\n${JSON.stringify({ fullName: current.full_name, email: current.email, phone: current.phone, linkedinUrl: current.linkedin_url })}\n\nטקסט קורות החיים:\n${String(current.cv_extracted_text).slice(0, 150000)}`, text: { verbosity: "medium", format: { type: "json_schema", name: "candidate_cv_details", strict: true, schema } } }) });
    const raw = await response.json() as Record<string, unknown>;
    if (!response.ok) return Response.json({ error: `שגיאת OpenAI: ${String((raw.error as Record<string, unknown> | undefined)?.message || response.status)}` }, { status: 502 });
    const items = Array.isArray(raw.output) ? raw.output as Array<Record<string, unknown>> : [];
    const outputText = String(raw.output_text || items.flatMap(item => Array.isArray(item.content) ? item.content as Array<Record<string, unknown>> : []).find(content => content.type === "output_text")?.text || "");
    if (!outputText) return Response.json({ error: "המודל לא החזיר פרטים" }, { status: 502 });
    const parsed = JSON.parse(outputText) as Record<string, unknown>;
    const uncertainties = Array.isArray(parsed.uncertainties) ? parsed.uncertainties as string[] : [];
    const details = {
      fullName: parsed.fullName || current.full_name || "", email: parsed.email || current.email || "", phone: parsed.phone || current.phone || "", linkedinUrl: parsed.linkedinUrl || current.linkedin_url || "",
      professionalTitle: parsed.professionalTitle || current.professional_title || "", company: parsed.company || current.company || "", yearsExperience: Number(parsed.yearsExperience || current.years_experience || 0),
      technologies: Array.isArray(parsed.technologies) && parsed.technologies.length ? parsed.technologies : JSON.parse(String(current.technologies || "[]")), experienceSummary: parsed.experienceSummary || current.experience_summary || "",
      notes: { professionalTitle: "חולץ באמצעות AI - יש לאמת מול התפקיד האחרון בקורות החיים", company: "חולץ באמצעות AI - יש לאמת", years: uncertainties.join(" · ") || "חושב לפי תקופות התעסוקה - יש לאמת", summary: "נוסח בעברית באמצעות AI על בסיס קורות החיים בלבד" },
    };
    const usage = usageAndCost(raw, model);
    await env.DB.prepare(`INSERT INTO ai_activity_logs (action_type,subject_type,subject_id,subject_label,model,input_tokens,cached_input_tokens,output_tokens,estimated_cost_usd) VALUES (?,?,?,?,?,?,?,?,?)`).bind("חילוץ פרטי מועמד מקורות חיים","candidate",Number(current.id),String(details.fullName || "מועמד"),model,usage.input,usage.cached,usage.output,usage.cost).run();
    return Response.json({ details, usage });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "חילוץ הפרטים באמצעות AI נכשל" }, { status: 500 });
  }
}
import { requireAppIdentity } from "../../../../lib/app-auth";
import { CV_EXTRACTION_INSTRUCTIONS } from "../../../../lib/ai-instructions";
