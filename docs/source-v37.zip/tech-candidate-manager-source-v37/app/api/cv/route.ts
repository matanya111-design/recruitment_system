async function getBindings(): Promise<{ db: D1Database; bucket: R2Bucket }> {
  const { env } = await import("cloudflare:workers");
  if (!env.DB || !env.BUCKET) throw new Error("Storage binding is unavailable");
  return { db: env.DB, bucket: env.BUCKET };
}

const MAX_FILE_SIZE = 10 * 1024 * 1024;

const TECH_TERMS = [
  "Python",
  "PySpark",
  "Spark",
  "SQL",
  "Kafka",
  "Flink",
  "Airflow",
  "Prefect",
  "Databricks",
  "Snowflake",
  "Hadoop",
  "Hive",
  "Impala",
  "HBase",
  "Trino",
  "NiFi",
  "Elasticsearch",
  "OpenSearch",
  "Linux",
  "Ansible",
  "Terraform",
  "Docker",
  "Kubernetes",
  "OpenShift",
  "Helm",
  "Argo CD",
  "Jenkins",
  "GitHub Actions",
  "GitLab CI",
  "AWS",
  "Azure",
  "GCP",
  "S3",
  "Glue",
  "Athena",
  "Lambda",
  "EKS",
  "ECS",
  "EC2",
  "RDS",
  "PostgreSQL",
  "MySQL",
  "MongoDB",
  "Redis",
  "Cassandra",
  "Java",
  "C++",
  "C#",
  "Scala",
  "Go",
  "FastAPI",
  "Flask",
  "Django",
  "MLflow",
  "vLLM",
  "Grafana",
  "Prometheus",
  "Splunk",
  "CI/CD",
  "ETL",
  "ELT",
];
const PROFESSIONAL_TITLE_PATTERN = /\b(?:senior\s+|lead\s+|principal\s+|head\s+of\s+|team\s+lead\s+)?(?:data\s+engineer|data\s+architect|data\s+platform(?:s)?\s+(?:engineer|administrator|lead)|devops\s+engineer|cloud\s+engineer|platform\s+engineer|machine\s+learning\s+engineer|ml\s+engineer|mlops\s+engineer|software\s+engineer|backend\s+developer|data\s+analyst|bi\s+developer)\b/i;

function parseResume(text: string, current: Record<string, unknown>) {
  const compact = text.replace(/\u0000/g, "").replace(/[ \t]+/g, " ");
  const lines = compact
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const email =
    compact.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] || "";
  const linkedin =
    compact.match(
      /(?:https?:\/\/)?(?:www\.)?linkedin\.com\/in\/[A-Za-z0-9_%\-]+\/?/i,
    )?.[0] || "";
  const phoneCandidates =
    compact.match(
      /(?:\+?972[-\s]?(?:\(0\))?[-\s]?|0)(?:5\d|[23489])[-\s]?\d{3}[-\s]?\d{4}/g,
    ) || [];
  const excluded =
    /resume|curriculum|vitae|cv|linkedin|email|phone|profile|summary|experience|education|skills|contact/i;
  const name =
    lines
      .slice(0, 18)
      .find(
        (line) =>
          line.length >= 5 &&
          line.length <= 55 &&
          !excluded.test(line) &&
          !line.includes("@") &&
          !/\d/.test(line) &&
          /^[A-Za-z\u0590-\u05ff'’.-]+(?:\s+[A-Za-z\u0590-\u05ff'’.-]+){1,3}$/.test(
            line,
          ),
      ) || "";
  const technologies = TECH_TERMS.filter((term) =>
    new RegExp(
      `(^|[^A-Za-z0-9+#])${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^A-Za-z0-9+#]|$)`,
      "i",
    ).test(compact),
  );
  const professionalTitle =
    lines.slice(0, 45).find((line) => line.length <= 90 && PROFESSIONAL_TITLE_PATTERN.test(line)) || "";
  const explicitYears = compact.match(
    /(\d{1,2})\+?\s*(?:years?|שנות?)\s+(?:of\s+)?(?:experience|ניסיון)/i,
  );
  let yearsExperience = explicitYears ? Number(explicitYears[1]) : 0;
  let yearsNote = explicitYears
    ? "זוהה ניסוח מפורש בקורות החיים"
    : "לא זוהה מספר שנות ניסיון מפורש";
  if (!yearsExperience) {
    const years = (compact.match(/\b(?:19|20)\d{2}\b/g) || [])
      .map(Number)
      .filter((y) => y >= 1990 && y <= new Date().getFullYear());
    if (years.length) {
      yearsExperience = Math.min(
        40,
        Math.max(0, new Date().getFullYear() - Math.min(...years)),
      );
      yearsNote =
        "הערכה לפי השנה המוקדמת בקובץ - יש לאמת, כי היא עלולה להיות שנת לימודים";
    }
  }
  const summary = technologies.length
    ? `בקורות החיים מופיע ניסיון מקצועי בעולמות הטכנולוגיה, עם דגש על ${technologies.slice(0, 8).join(", ")}.${yearsExperience ? ` הוותק המשוער הוא כ-${yearsExperience} שנים, אך יש לאמת אותו מול תקופות התעסוקה.` : " לא זוהה ותק מפורש ויש להשלים אותו ידנית."} התקציר מבוסס על חילוץ אוטומטי ואינו קובע את עומק הניסיון בכל טכנולוגיה.`
    : `קורות החיים נקלטו, אך לא זוהה מידע מספיק ליצירת תקציר מקצועי אמין. יש לעבור על המסמך ולהשלים את התקציר ידנית.`;
  return {
    fullName: name || String(current.full_name || ""),
    email: email || String(current.email || ""),
    phone:
      phoneCandidates[0]?.replace(/\s+/g, " ") || String(current.phone || ""),
    linkedinUrl: linkedin
      ? linkedin.startsWith("http")
        ? linkedin
        : `https://${linkedin}`
      : String(current.linkedin_url || ""),
    professionalTitle:
      professionalTitle || String(current.professional_title || ""),
    company: String(current.company || ""),
    yearsExperience: yearsExperience || Number(current.years_experience || 0),
    technologies: technologies.length
      ? technologies
      : JSON.parse(String(current.technologies || "[]")),
    experienceSummary: summary,
    notes: {
      professionalTitle: professionalTitle
        ? "זוהה ניסוח תפקיד בקורות החיים - יש לאמת שזהו התפקיד הנוכחי או האחרון"
        : "לא זוהה תפקיד מקצועי אמין - יש להשלים ידנית",
      company: "חברה נוכחית אינה מתעדכנת אוטומטית ללא זיהוי אמין",
      years: yearsNote,
      summary: "התקציר נוצר בעברית מהמידע שזוהה ואינו הערכת התאמה",
    },
  };
}

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const form = await request.formData();
    const file = form.get("file");
    const applicationId = Number(form.get("applicationId"));
    if (!(file instanceof File) || !applicationId)
      return Response.json(
        { error: "חסר קובץ או מזהה מועמדות" },
        { status: 400 },
      );
    if (file.size > MAX_FILE_SIZE)
      return Response.json(
        { error: "ניתן להעלות PDF עד 10MB" },
        { status: 400 },
      );

    const bytes = new Uint8Array(await file.arrayBuffer());
    const signature = new TextDecoder().decode(bytes.slice(0, 5));
    if (file.type !== "application/pdf" || signature !== "%PDF-")
      return Response.json(
        { error: "יש להעלות קובץ PDF תקין בלבד" },
        { status: 400 },
      );

    const { db, bucket } = await getBindings();
    const application = await db
      .prepare(
        "SELECT c.id candidate_id,c.cv_key FROM applications a JOIN candidates c ON c.id=a.candidate_id WHERE a.id=? AND a.archived=0 AND c.archived=0",
      )
      .bind(applicationId)
      .first<{ candidate_id: number; cv_key: string | null }>();
    if (!application)
      return Response.json({ error: "המועמדות לא נמצאה" }, { status: 404 });

    let extractedText = "";
    let pages: number | null = null;
    let extractionStatus = "הטקסט חולץ";
    try {
      const { extractText, getDocumentProxy } = await import("unpdf");
      const pdf = await getDocumentProxy(bytes);
      const result = await extractText(pdf, { mergePages: true });
      pages = result.totalPages;
      extractedText = String(result.text || "")
        .slice(0, 200000)
        .trim();
      if (!extractedText)
        extractionStatus = "לא נמצא טקסט - ייתכן שזה PDF סרוק";
    } catch {
      extractionStatus = "הקובץ נשמר, חילוץ הטקסט נכשל";
    }

    const safeName =
      file.name.replace(/[^a-zA-Z0-9._\-\u0590-\u05ff]/g, "_").slice(0, 120) ||
      "resume.pdf";
    const key = `candidate-cvs/${applicationId}/${crypto.randomUUID()}-${safeName}`;
    await bucket.put(key, bytes, {
      httpMetadata: {
        contentType: "application/pdf",
        contentDisposition: `inline; filename="${safeName}"`,
      },
    });
    await db
      .prepare(
        `UPDATE candidates SET cv_key=?,cv_filename=?,cv_content_type='application/pdf',cv_size=?,cv_pages=?,cv_extracted_text=?,cv_extraction_status=?,cv_uploaded_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`,
      )
      .bind(
        key,
        file.name.slice(0, 180),
        file.size,
        pages,
        extractedText,
        extractionStatus,
        application.candidate_id,
      )
      .run();
    await db.prepare(`UPDATE applications SET
      status=CASE WHEN status='חדש' THEN 'בבדיקה' ELSE status END,
      next_action=CASE WHEN next_action IN ('','בדיקת קורות חיים','העלאת קורות חיים') THEN 'אימות פרטי קורות חיים' ELSE next_action END,
      updated_at=CURRENT_TIMESTAMP WHERE candidate_id=?`).bind(application.candidate_id).run();
    if (application.cv_key && application.cv_key !== key)
      await bucket.delete(application.cv_key).catch(() => undefined);

    return Response.json({
      ok: true,
      filename: file.name,
      size: file.size,
      pages,
      textLength: extractedText.length,
      extractionStatus,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "העלאת הקובץ נכשלה" },
      { status: 500 },
    );
  }
}

export async function GET(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const url = new URL(request.url);
    const applicationId = Number(url.searchParams.get("applicationId"));
    if (!applicationId)
      return Response.json({ error: "חסר מזהה מועמדות" }, { status: 400 });
    const { db, bucket } = await getBindings();
    if (url.searchParams.get("mode") === "details") {
      const row = await db
        .prepare(
          `SELECT c.cv_extracted_text,c.full_name,c.phone,c.email,c.linkedin_url,c.professional_title,c.company,c.years_experience,c.technologies,c.experience_summary
        FROM applications a JOIN candidates c ON c.id=a.candidate_id WHERE a.id=? AND a.archived=0`,
        )
        .bind(applicationId)
        .first<Record<string, unknown>>();
      if (!row)
        return Response.json({ error: "המועמדות לא נמצאה" }, { status: 404 });
      if (!row.cv_extracted_text)
        return Response.json(
          { error: "לא נמצא טקסט שחולץ מקורות החיים" },
          { status: 422 },
        );
      return Response.json({
        details: parseResume(String(row.cv_extracted_text), row),
      });
    }
    const row = await db
      .prepare(
        "SELECT c.cv_key,c.cv_filename FROM applications a JOIN candidates c ON c.id=a.candidate_id WHERE a.id=? AND a.archived=0 AND c.archived=0",
      )
      .bind(applicationId)
      .first<{ cv_key: string | null; cv_filename: string | null }>();
    if (!row?.cv_key)
      return Response.json({ error: "לא נמצאו קורות חיים" }, { status: 404 });
    const object = await bucket.get(row.cv_key);
    if (!object)
      return Response.json({ error: "הקובץ לא נמצא באחסון" }, { status: 404 });
    return new Response(object.body, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(row.cv_filename || "resume.pdf")}`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "פתיחת הקובץ נכשלה" },
      { status: 500 },
    );
  }
}
import { requireAppIdentity } from "../../../lib/app-auth";
