import { requireAppIdentity } from "../../../../lib/app-auth";

const refinementSchema = {
  type: "object",
  additionalProperties: false,
  required: ["summary", "changes", "questions", "draft"],
  properties: {
    summary: { type: "string" },
    changes: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["field", "action", "reason"],
        properties: {
          field: { type: "string" },
          action: { type: "string" },
          reason: { type: "string" },
        },
      },
    },
    questions: { type: "array", items: { type: "string" } },
    draft: {
      type: "object",
      additionalProperties: false,
      required: ["title", "client", "description", "mustRequirements", "preferredRequirements", "technologies", "minYears", "professionalEmphasis", "personalityEmphasis", "internalNotes"],
      properties: {
        title: { type: "string" }, client: { type: "string" }, description: { type: "string" },
        mustRequirements: { type: "string" }, preferredRequirements: { type: "string" },
        technologies: { type: "array", items: { type: "string" } },
        minYears: { anyOf: [{ type: "integer", minimum: 0 }, { type: "null" }] },
        professionalEmphasis: { type: "string" }, personalityEmphasis: { type: "string" }, internalNotes: { type: "string" },
      },
    },
  },
} as const;

function usageAndCost(raw: Record<string, unknown>, model: string) {
  const usage = (raw.usage || {}) as Record<string, unknown>;
  const input = Number(usage.input_tokens || 0), output = Number(usage.output_tokens || 0);
  const cached = Number(((usage.input_tokens_details || {}) as Record<string, unknown>).cached_tokens || 0);
  const rates = model.includes("sol") ? [5, .5, 30] : model.includes("luna") ? [.2, .02, 1.2] : [2, .2, 12];
  return { input, output, cached, cost: ((input - cached) * rates[0] + cached * rates[1] + output * rates[2]) / 1_000_000 };
}

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const body = await request.json() as { source?: string; job?: Record<string, unknown> };
    const source = String(body.source || "").trim();
    if (source.length < 20) return Response.json({ error: "יש להדביק מידע משמעותי לעדכון המשרה" }, { status: 400 });
    if (source.length > 120000) return Response.json({ error: "הטקסט ארוך מדי. יש לצמצם קטעים שאינם רלוונטיים" }, { status: 413 });
    if (!body.job) return Response.json({ error: "פרטי המשרה הקיימת חסרים" }, { status: 400 });

    const { env } = await import("cloudflare:workers");
    if (!env.OPENAI_API_KEY) return Response.json({ error: "מנוע ה-AI אינו מוגדר באתר" }, { status: 503 });
    const model = String(env.OPENAI_MODEL || "gpt-5.6-terra");
    const instructions = `אתה מסייע למנהל גיוס לעדכן משרה קיימת לפי מידע חדש, כגון תמלול שיחה עם מנהל מגייס.\n
- השווה בין המשרה הקיימת למידע החדש והחזר דוח שינויים קצר וברור בעברית.\n
- אין להמציא מידע ואין למחוק דרישה קיימת אלא אם המידע החדש אומר במפורש שאינה נדרשת.\n
- אם קיימת סתירה או אי-ודאות, השאר את הערך הקיים והוסף שאלה ל-questions.\n
- הבחן בין חובה, יתרון, דגש מקצועי, דגש אישיותי והערה פנימית.\n
- draft חייב להיות גרסה מלאה של המשרה לאחר השינויים, כולל שדות שלא השתנו.\n
- changes יכיל רק שינויים ממשיים. field יהיה שם שדה ידידותי, action יתאר בקצרה מה ישתנה, reason יסביר על סמך מה.\n
- אם אין שינוי מוצדק, החזר changes ריק ואל תשנה את draft.`;
    const input = `המשרה הקיימת:\n${JSON.stringify(body.job, null, 2)}\n\nהמידע החדש:\n${source}`;
    const response = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ model, store: false, reasoning: { effort: "low" }, instructions, input, text: { verbosity: "medium", format: { type: "json_schema", name: "job_refinement", strict: true, schema: refinementSchema } } }) });
    const raw = await response.json() as Record<string, unknown>;
    if (!response.ok) return Response.json({ error: `שגיאת OpenAI: ${String((raw.error as Record<string, unknown> | undefined)?.message || response.status)}` }, { status: 502 });
    const items = Array.isArray(raw.output) ? raw.output as Array<Record<string, unknown>> : [];
    const outputText = String(raw.output_text || items.flatMap(item => Array.isArray(item.content) ? item.content as Array<Record<string, unknown>> : []).find(content => content.type === "output_text")?.text || "");
    if (!outputText) return Response.json({ error: "המודל לא החזיר הצעת עדכון" }, { status: 502 });
    const refinement = JSON.parse(outputText) as Record<string, unknown>;
    const usage = usageAndCost(raw, model);
    if (env.DB) {
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS ai_activity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,action_type TEXT NOT NULL,subject_type TEXT NOT NULL DEFAULT '',subject_id INTEGER,subject_label TEXT NOT NULL DEFAULT '',model TEXT NOT NULL,input_tokens INTEGER NOT NULL DEFAULT 0,cached_input_tokens INTEGER NOT NULL DEFAULT 0,output_tokens INTEGER NOT NULL DEFAULT 0,estimated_cost_usd REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
      await env.DB.prepare(`INSERT INTO ai_activity_logs (action_type,subject_type,subject_id,subject_label,model,input_tokens,cached_input_tokens,output_tokens,estimated_cost_usd) VALUES (?,?,?,?,?,?,?,?,?)`).bind("ניתוח עדכון משרה", "job", Number(body.job.id || 0) || null, `${String(body.job.title || "משרה")} · ${String(body.job.client || "")}`, model, usage.input, usage.cached, usage.output, usage.cost).run();
    }
    return Response.json({ refinement, usage });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "ניתוח העדכון נכשל" }, { status: 500 });
  }
}
