const jobDraftSchema = {
  type: "object", additionalProperties: false,
  required: ["title","client","description","mustRequirements","preferredRequirements","technologies","minYears","professionalEmphasis","personalityEmphasis","internalNotes","uncertainties"],
  properties: {
    title:{type:"string"}, client:{type:"string"}, description:{type:"string"}, mustRequirements:{type:"string"}, preferredRequirements:{type:"string"},
    technologies:{type:"array",items:{type:"string"}}, minYears:{anyOf:[{type:"integer",minimum:0},{type:"null"}]},
    professionalEmphasis:{type:"string"}, personalityEmphasis:{type:"string"}, internalNotes:{type:"string"}, uncertainties:{type:"array",items:{type:"string"}}
  }
} as const;

function usageAndCost(raw: Record<string, unknown>, model: string) {
  const usage=(raw.usage||{}) as Record<string,unknown>;
  const input=Number(usage.input_tokens||0), output=Number(usage.output_tokens||0);
  const cached=Number(((usage.input_tokens_details||{}) as Record<string,unknown>).cached_tokens||0);
  const rates=model.includes("sol")?[5,0.5,30]:model.includes("luna")?[0.2,0.02,1.2]:[2,0.2,12];
  return {input,output,cached,cost:((input-cached)*rates[0]+cached*rates[1]+output*rates[2])/1_000_000};
}

export async function POST(request: Request) {
  const identity = await requireAppIdentity(request);
  if (identity instanceof Response) return identity;
  try {
    const { text } = await request.json() as { text?: string };
    const source=String(text||"").trim();
    if(source.length<20)return Response.json({error:"יש להדביק טקסט משמעותי של המשרה"},{status:400});
    if(source.length>120000)return Response.json({error:"הטקסט ארוך מדי. יש לצמצם חתימות וקבצים מצורפים"},{status:413});
    const {env}=await import("cloudflare:workers");
    if(!env.OPENAI_API_KEY)return Response.json({error:"מנוע ה-AI אינו מוגדר באתר"},{status:503});
    const model=String(env.OPENAI_MODEL||"gpt-5.6-terra");
    const saved = env.DB ? await env.DB.prepare("SELECT content FROM ai_instructions WHERE key='job_parsing'").first<{content:string}>().catch(()=>null) : null;
    const instructions = saved?.content || JOB_PARSING_INSTRUCTIONS;
    const response=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({model,store:false,reasoning:{effort:"low"},instructions,input:`חומר הגלם למשרה:\n\n${source}`,text:{verbosity:"medium",format:{type:"json_schema",name:"job_draft",strict:true,schema:jobDraftSchema}}})});
    const raw=await response.json() as Record<string,unknown>;
    if(!response.ok)return Response.json({error:`שגיאת OpenAI: ${String((raw.error as Record<string,unknown>|undefined)?.message||response.status)}`},{status:502});
    const items=Array.isArray(raw.output)?raw.output as Array<Record<string,unknown>>:[];
    const outputText=String(raw.output_text||items.flatMap(item=>Array.isArray(item.content)?item.content as Array<Record<string,unknown>>:[]).find(content=>content.type==="output_text")?.text||"");
    if(!outputText)return Response.json({error:"המודל לא החזיר טיוטת משרה"},{status:502});
    const draft=JSON.parse(outputText) as Record<string,unknown>;
    const usage=usageAndCost(raw,model);
    if(env.DB){
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS ai_activity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,action_type TEXT NOT NULL,subject_type TEXT NOT NULL DEFAULT '',subject_id INTEGER,subject_label TEXT NOT NULL DEFAULT '',model TEXT NOT NULL,input_tokens INTEGER NOT NULL DEFAULT 0,cached_input_tokens INTEGER NOT NULL DEFAULT 0,output_tokens INTEGER NOT NULL DEFAULT 0,estimated_cost_usd REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
      await env.DB.prepare(`INSERT INTO ai_activity_logs (action_type,subject_type,subject_label,model,input_tokens,cached_input_tokens,output_tokens,estimated_cost_usd) VALUES (?,?,?,?,?,?,?,?)`).bind("יצירת טיוטת משרה","job",`${String(draft.title||"משרה ללא שם")} · ${String(draft.client||"לקוח לא ידוע")}`,model,usage.input,usage.cached,usage.output,usage.cost).run();
    }
    return Response.json({draft,usage});
  } catch(error) { return Response.json({error:error instanceof Error?error.message:"יצירת טיוטת המשרה נכשלה"},{status:500}); }
}
import { requireAppIdentity } from "../../../../lib/app-auth";
import { JOB_PARSING_INSTRUCTIONS } from "../../../../lib/ai-instructions";
