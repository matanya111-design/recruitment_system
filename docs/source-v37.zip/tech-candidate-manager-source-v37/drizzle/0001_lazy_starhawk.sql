ALTER TABLE `applications` ADD `cv_key` text;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_filename` text;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_content_type` text;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_size` integer;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_pages` integer;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_extracted_text` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_extraction_status` text DEFAULT 'לא הועלה' NOT NULL;--> statement-breakpoint
ALTER TABLE `applications` ADD `cv_uploaded_at` text;