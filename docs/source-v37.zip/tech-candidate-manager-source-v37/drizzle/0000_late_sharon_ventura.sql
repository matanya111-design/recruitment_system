CREATE TABLE `applications` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`candidate_id` integer NOT NULL,
	`job_id` integer NOT NULL,
	`status` text DEFAULT 'חדש' NOT NULL,
	`interview_date` text,
	`interview_summary` text DEFAULT '' NOT NULL,
	`next_action` text DEFAULT '' NOT NULL,
	`next_action_date` text,
	`score` integer,
	`recommendation` text DEFAULT 'טרם הוערך' NOT NULL,
	`evaluation_type` text DEFAULT 'ראשונית' NOT NULL,
	`evaluation_date` text,
	`archived` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `candidates` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`full_name` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`linkedin_url` text DEFAULT '' NOT NULL,
	`company` text DEFAULT '' NOT NULL,
	`years_experience` integer,
	`technologies` text DEFAULT '[]' NOT NULL,
	`experience_summary` text DEFAULT '' NOT NULL,
	`archived` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`client` text NOT NULL,
	`status` text DEFAULT 'פעילה' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`must_requirements` text DEFAULT '' NOT NULL,
	`preferred_requirements` text DEFAULT '' NOT NULL,
	`technologies` text DEFAULT '[]' NOT NULL,
	`min_years` integer,
	`professional_emphasis` text DEFAULT '' NOT NULL,
	`personality_emphasis` text DEFAULT '' NOT NULL,
	`internal_notes` text DEFAULT '' NOT NULL,
	`archived` integer DEFAULT false NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
